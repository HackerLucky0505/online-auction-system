﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineAuctionSystem.Models
{
    [Table("saved_auctions")]
    public class SavedAuction
    {
        public int Id { get; set; }

        public int UserId { get; set; }
        public int AuctionId { get; set; }

        public string Title { get; set; }
        public string ImagePath { get; set; }

        // price jab user ne save kiya
        public decimal SavedPrice { get; set; }

        public DateTime SavedAt { get; set; }

        // ✅ Navigation property
        public Auction Auction { get; set; }
    }
}
