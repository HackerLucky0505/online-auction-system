﻿const userBtn = document.getElementById("userBtn");
const adminBtn = document.getElementById("adminBtn");
const roleInput = document.getElementById("role");
const infoText = document.getElementById("infoText");

userBtn.onclick = () => {
    userBtn.classList.add("active");
    adminBtn.classList.remove("active");
    roleInput.value = "User";
    infoText.innerText = "Login as User to place bids";
};

adminBtn.onclick = () => {
    adminBtn.classList.add("active");
    userBtn.classList.remove("active");
    roleInput.value = "Admin";
    infoText.innerText = "Login as Admin to manage auctions";
};
