﻿using Microsoft.AspNetCore.Mvc;
using OnlineAuctionSystem.Data;
using OnlineAuctionSystem.Models;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace OnlineAuctionSystem.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        // ================= REGISTER =================

        public IActionResult Register()
        {
            return View();
        }



        [HttpPost]
        public IActionResult Register(string name, string email, string password)
        {
            var existingUser = _context.Users
                .FirstOrDefault(u => u.Email == email);

            if (existingUser != null)
            {
                ViewBag.Error = "❌ This email is already used";
                return View();
            }

            var user = new Models.User
            {
                Name = name,
                Email = email,
                Password = password,
                Role = "User"
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            ViewBag.Success = "✅ Registration successful! Please login.";
            return RedirectToAction("Login");
        }

        // ================= LOGIN =================

        public IActionResult Login()
        {
            return View();
        }



        [HttpPost]
        //public IActionResult Login(string email, string password)
        //{
        //    var user = _context.Users
        //        .FirstOrDefault(u => u.Email == email && u.Password == password);

        //    if (user == null)
        //    {
        //        ViewBag.Error = "❌ No user found with this Email or Password";
        //        return View();
        //    }

        //    HttpContext.Session.SetString("UserRole", user.Role);
        //    HttpContext.Session.SetString("UserEmail", user.Email);

        //    if (user.Role == "Admin")
        //        return RedirectToAction("Dashboard", "Admin");

        //    return RedirectToAction("Dashboard", "User");
        //}
        [HttpPost]
        public IActionResult Login(string email, string password, string role)
        {
            var user = _context.Users.FirstOrDefault(u =>
                u.Email == email &&
                u.Password == password &&
                u.Role == role
            );

            if (user == null)
            {
                ViewBag.Error = $"❌ Invalid credentials for {role} login";
                return View();
            }

            HttpContext.Session.SetString("UserRole", user.Role);
            HttpContext.Session.SetString("UserEmail", user.Email);
            HttpContext.Session.SetInt32("UserId", user.Id);

            if (user.Role == "Admin")
                return RedirectToAction("Dashboard", "Admin");

            return RedirectToAction("Dashboard", "User");
        }


        // ================= LOGOUT =================
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
            Response.Headers["Pragma"] = "no-cache";
            Response.Headers["Expires"] = "0";

            return RedirectToAction("Login", "Account");
        }



        //public IActionResult Logout()
        //{
        //    HttpContext.Session.Clear();
        //    return RedirectToAction("Login");
        //}
    }
}
