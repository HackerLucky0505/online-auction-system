﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineAuctionSystem.Models
{
    
    public class Auction
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        public decimal StartingPrice { get; set; }
        public decimal CurrentPrice { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        public string ImagePath { get; set; }
        public bool IsLive { get; set; }   // 🔥 LIVE CONTROL
        public int? WinnerUserId { get; set; }

        public ICollection<Bid> Bids { get; set; }
        public bool IsDeleted { get; set; } = false;
        

    }
}
