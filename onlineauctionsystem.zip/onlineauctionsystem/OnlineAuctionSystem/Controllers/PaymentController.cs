﻿using Microsoft.AspNetCore.Mvc;

namespace OnlineAuctionSystem.Controllers
{
    public class PaymentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
