﻿using Microsoft.AspNetCore.Mvc;

namespace OnlineAuctionSystem.Controllers
{
    public class BidController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
