﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using OnlineAuctionSystem.Data;
using OnlineAuctionSystem.Models;
using System.Linq;

namespace OnlineAuctionSystem.Controllers
{
    public class UserController : Controller
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Dashboard()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserRole")))
                return RedirectToAction("Login", "Account");

            if (HttpContext.Session.GetString("UserRole") == "Admin")
                return RedirectToAction("Dashboard", "Admin");

            int userId = Convert.ToInt32(HttpContext.Session.GetInt32("UserId"));

            // 🔥 All live auctions
            var auctions = _context.Auctions
                .Where(a => a.IsLive)
                .ToList();

            // 🔥 User saved auctions WITH Auction data
            var myBids = _context.SavedAuctions
                .Include(sa => sa.Auction)   // ✅ THIS IS THE KEY FIX
                .Where(sa => sa.UserId == userId)
                .OrderByDescending(sa => sa.SavedAt)
                .ToList();

            ViewBag.MyBids = myBids;

            return View(auctions);
        }

        public IActionResult AddToMyBids(int id)
        {
            int UserId = Convert.ToInt32(HttpContext.Session.GetInt32("UserId"));

            var auction = _context.Auctions.FirstOrDefault(a => a.Id == id);
            if (auction == null) return NotFound();

            bool exists = _context.SavedAuctions
                .Any(x => x.UserId == UserId && x.AuctionId == id);

            if (exists)
                return RedirectToAction("Dashboard");

            var saved = new SavedAuction
            {
                UserId = UserId,
                AuctionId = auction.Id,
                Title = auction.Title,
                ImagePath = auction.ImagePath,
                SavedPrice = auction.CurrentPrice,
                SavedAt = DateTime.Now
            };

            _context.SavedAuctions.Add(saved);
            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }
        [HttpPost]
        public IActionResult PlaceBid(int auctionId, decimal bidAmount)
        {
            int userId = Convert.ToInt32(HttpContext.Session.GetInt32("UserId"));

            var auction = _context.Auctions.FirstOrDefault(a => a.Id == auctionId);

            if (auction == null || !auction.IsLive)
            {
                TempData["Error"] = "Auction not live!";
                return RedirectToAction("Dashboard");
            }

            bool isSaved = _context.SavedAuctions
                .Any(x => x.UserId == userId && x.AuctionId == auctionId);

            if (!isSaved)
            {
                TempData["Error"] = "Please add auction to My Bids first!";
                return RedirectToAction("Dashboard");
            }

            if (bidAmount <= auction.CurrentPrice)
            {
                TempData["Error"] = "Bid must be higher than current price!";
                return RedirectToAction("Dashboard");
            }

            var bid = new Bid
            {
                AuctionId = auctionId,
                UserId = userId,
                BidAmount = bidAmount,
                BidTime = DateTime.Now
            };

            _context.Bids.Add(bid);
            auction.CurrentPrice = bidAmount;

            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }

    }
}
