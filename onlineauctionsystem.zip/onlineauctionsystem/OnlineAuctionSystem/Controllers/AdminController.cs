﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineAuctionSystem.Data;
using OnlineAuctionSystem.Models;

namespace OnlineAuctionSystem.Controllers
{
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public class AdminController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public AdminController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // 🔐 ADMIN DASHBOARD
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult Dashboard()
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Login", "Account");

            var auctions = _context.Auctions.ToList();

            foreach (var auction in auctions)
            {
                if (auction.EndTime <= DateTime.Now && auction.IsLive)
                {
                    auction.IsLive = false;

                    var highestBid = _context.Bids
                        .Where(b => b.AuctionId == auction.Id)
                        .OrderByDescending(b => b.BidAmount)
                        .FirstOrDefault();

                    if (highestBid != null)
                        auction.WinnerUserId = highestBid.UserId;
                }
            }

            _context.SaveChanges();

            return View(auctions);
        }

        // ➕ CREATE AUCTION (GET)
        public IActionResult CreateAuction()
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Login", "Account");

            return View();
        }

        // ➕ CREATE AUCTION (POST)
        [HttpPost]
        public IActionResult CreateAuction(Auction auction, IFormFile image)
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
                return RedirectToAction("Login", "Account");

            if (image != null)
            {
                string uploadsFolder = Path.Combine(_env.WebRootPath, "uploads");
                Directory.CreateDirectory(uploadsFolder);

                string fileName = Guid.NewGuid() + Path.GetExtension(image.FileName);
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream);
                }

                auction.ImagePath = "uploads/" + fileName;
            }

            auction.CurrentPrice = auction.StartingPrice;
            auction.IsLive = false;

            _context.Auctions.Add(auction);
            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }

        public IActionResult GoLive(int id)
        {
            var auction = _context.Auctions.Find(id);
            if (auction == null) return NotFound();

            if (auction.StartTime > DateTime.Now)
            {
                TempData["Error"] = "Auction start time has not arrived yet!";
                return RedirectToAction("Dashboard");
            }

            auction.IsLive = true;
            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }

        public IActionResult EditAuction(int id)
        {
            var auction = _context.Auctions.Find(id);

            if (auction == null)
                return NotFound();

            if (auction.IsLive)
            {
                TempData["Error"] = "Live auction cannot be updated!";
                return RedirectToAction("Dashboard");
            }

            return View(auction);
        }

        [HttpPost]
        public IActionResult EditAuction(Auction model)
        {
            var auction = _context.Auctions.Find(model.Id);

            if (auction.IsLive)
            {
                TempData["Error"] = "Live auction cannot be updated!";
                return RedirectToAction("Dashboard");
            }

            auction.Title = model.Title;
            auction.Description = model.Description;
            auction.StartTime = model.StartTime;
            auction.EndTime = model.EndTime;

            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }

        public IActionResult DeleteAuction(int id)
        {
            var auction = _context.Auctions.FirstOrDefault(a => a.Id == id);

            if (auction == null)
                return NotFound();

            if (auction.IsLive)
            {
                TempData["Error"] = "Live auction cannot be deleted";
                return RedirectToAction("Dashboard");
            }

            _context.Auctions.Remove(auction);
            _context.SaveChanges();

            TempData["Success"] = "Auction deleted successfully";
            return RedirectToAction("Dashboard");
        }

        public IActionResult AddToMyBids(int id)
        {
            int userId = Convert.ToInt32(HttpContext.Session.GetInt32("UserId"));

            var auction = _context.Auctions.FirstOrDefault(a => a.Id == id);
            if (auction == null) return NotFound();

            bool exists = _context.SavedAuctions
                .Any(x => x.UserId == userId && x.AuctionId == id);

            if (exists)
                return RedirectToAction("Dashboard");

            var saved = new SavedAuction
            {
                UserId = userId,
                AuctionId = auction.Id,
                Title = auction.Title,
                ImagePath = auction.ImagePath,
                SavedPrice = auction.CurrentPrice,
                SavedAt = DateTime.Now
            };

            _context.SavedAuctions.Add(saved);
            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }

   

    
    }
}
