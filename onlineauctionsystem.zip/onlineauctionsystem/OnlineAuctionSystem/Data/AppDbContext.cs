﻿using Microsoft.EntityFrameworkCore;
using OnlineAuctionSystem.Models;

namespace OnlineAuctionSystem.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }

        // 🔥 STEP 2 YAHAN ADD KARO
        public DbSet<Auction> Auctions { get; set; }
        public DbSet<Bid> Bids { get; set; }


        public DbSet<SavedAuction> SavedAuctions { get; set; }


    }
}
